# Static Site (GitHub Pages)

This folder is ready for GitHub Pages.

## Deploy (Web UI)
1. Create a new public repository on GitHub (no template).
2. Upload all files from this folder (including `.nojekyll`) to the repo root and commit.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
5. Select **Branch: `main`** and **Folder: `/ (root)`**, then **Save**.
6. GitHub will build your site. The public URL will be: `https://<your-username>.github.io/<repo-name>/`

## Custom domain (optional)
- In **Settings → Pages**, set your custom domain.
- Add a DNS **CNAME** record for your domain pointing to `<your-username>.github.io`.

## Notes
- Keep a root `index.html`. This project includes one that redirects to `/home/` and links to the other pages.
- If you change folder names or add pages, update links accordingly.